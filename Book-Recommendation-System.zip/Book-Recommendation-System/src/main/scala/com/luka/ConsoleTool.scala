package com.luka

import com.luka.db.DatabaseProcessor

import java.sql.DriverManager
import java.sql.Connection

object ConsoleTool {
  def main(args: Array[String]): Unit = {
    println("Please choose a number: ")
    println("1: Get book recommendation")
    println("2: Add a book to the database ")
    print("Enter the number: ")
    val option=scala.io.StdIn.readInt()

    if(option == 1){
      println("Finding recommended book")
      print("Please enter your age: ")
      val age=scala.io.StdIn.readInt()
      var ageRange = ""
      if (age < 13) ageRange = "'Children'"
      else if (age <= 19) ageRange = "'Young Adult'"
      else ageRange = "'Adult'"

      print("Please enter maximum price: ")
      val price = scala.io.StdIn.readDouble()

      print("Please enter maximum number of pages: ")
      val numberOfPages = scala.io.StdIn.readInt()

      println("Please choose your favorite genre: ")
      println("1: Fiction;")
      println("2: Adventure;")
      println("3: Drama;")
      println("4: Tragedy")

      var genre = ""
      val genreChoice=scala.io.StdIn.readInt()
      if (genreChoice == 1) genre = "'%Fiction%'"
      else if (genreChoice == 2) genre = "'%Adventure%'"
      else if (genreChoice == 3) genre = "'%Drama%'"
      else if (genreChoice == 4) genre = "'%Tragedy%'"

      val dbprocessor = new DatabaseProcessor()
      val result:String = dbprocessor.findRecommendedBook(ageRange,price,numberOfPages,genre)

    }else if(option ==2){
      println("Adding book to the database")
      print("What is the name of the book? ")
      var bookName2 = scala.io.StdIn.readLine()
      print("What is the name of the author? ")
      var author2 = scala.io.StdIn.readLine()
      print("What is the price of the book? ")
      var price2 = scala.io.StdIn.readDouble()
      print("What is the genre of the book? ")
      var genre2 = scala.io.StdIn.readLine()
      print("What is the recommended age range? ")
      var recommendedAge2 = scala.io.StdIn.readLine()
      print("What is the number of pages in the book? ")
      var numberOfPages2 = scala.io.StdIn.readInt()
      print("What year was the book written? ")
      var yearPublished2 = scala.io.StdIn.readInt()

      val dbprocessor = new DatabaseProcessor()
      dbprocessor.addBook(bookName2,author2,price2, genre2, recommendedAge2,numberOfPages2,yearPublished2)
    }
    else {
      println("The selection is invalid! Please try again!")
    }
  }
}