package com.luka.db

import java.sql.{Connection, DriverManager}

class DatabaseProcessor {

  def findRecommendedBook(ageRange: String, price:Double, pages:Int, genre:String): String = {

    val driver = "com.mysql.cj.jdbc.Driver"
    val url = "jdbc:mysql://localhost/Books"
    val username = "mysql"
    val password = "Tbilisi2021!"


    // there's probably a better way to do this
    var connection:Connection = null

    var myVar : String =""
    try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)

//      val author = "'Fyodor Dostoevsky'"
      val sqlQuery = "SELECT *  FROM BookList WHERE RecommendedAge = " +
        ageRange + "AND Price < " + price + " AND NumberOfPages < " +
        pages + " AND genre LIKE " + genre + " LIMIT 5"
      // create the statement, and run the select query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery(sqlQuery)
      var count = 1;
      while (resultSet.next()) {
        val bookTitle = resultSet.getString("BookTitle")
        val author = resultSet.getString("Author")
        println("Book Recommendation " + count + ": " + bookTitle + ", " + author)
        count += 1
        myVar = bookTitle+ author
      }
    } catch {
      case e => e.printStackTrace()
    } finally {
      connection.close()
    }
    myVar
  }

  def addBook (bookTitle:String, author:String, price:Double, genre:String, recommendedAge:String, numberOfPages:Int, yearPublished:Int): Unit = {
    val driver = "com.mysql.cj.jdbc.Driver"
    val url = "jdbc:mysql://localhost/Books"
    val username = "mysql"
    val password = "Tbilisi2021!"

    var connection:Connection = null
    var myVar : String =""
    try {
      // make the connection
      Class.forName(driver)
      connection = DriverManager.getConnection(url, username, password)

      val sqlQuery = "INSERT INTO BookList (BookTitle, Author, Price, Genre, RecommendedAge, NumberOfPages, YearPublished) VALUES ('" +
        bookTitle + "','" + author + "'," + price + ",'" + genre + "','" + recommendedAge +"', "+ numberOfPages + ", " + yearPublished + ")"
      // create the statement, and run the select query
      val statement = connection.createStatement()
      statement.executeUpdate(sqlQuery)

    } catch {
      case e => e.printStackTrace()
    } finally {
      println("The book has been successfully added.")
      connection.close()
    }
  }
}